package com.stars;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import net.milkbowl.vault.economy.EconomyResponse.ResponseType;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.file.FileConfiguration;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

@SuppressWarnings("deprecation")
public class StarsEconomy implements Economy {

    private final DataManager data;
    private final String singular;
    private final String plural;
    private final String symbol;
    private final int decimals;
    private final double maxBalance;

    public StarsEconomy(StarsPlugin plugin, DataManager data) {
        this.data = data;
        FileConfiguration config = plugin.getConfig();
        this.singular = config.getString("currency.singular", "Star");
        this.plural = config.getString("currency.plural", "Stars");
        this.symbol = config.getString("currency.symbol", "★");
        this.decimals = Math.max(0, Math.min(4, config.getInt("currency.decimals", 0)));
        this.maxBalance = config.getDouble("max-balance", 1_000_000_000_000.0);
    }

    // ------------------------------------------------------------------
    // Utilidades
    // ------------------------------------------------------------------

    public double round(double value) {
        double factor = Math.pow(10, decimals);
        return Math.round(value * factor) / factor;
    }

    private OfflinePlayer byName(String name) {
        OfflinePlayer cached = Bukkit.getOfflinePlayerIfCached(name);
        return cached != null ? cached : Bukkit.getOfflinePlayer(name);
    }

    private EconomyResponse fail(double balance, String message) {
        return new EconomyResponse(0, balance, ResponseType.FAILURE, message);
    }

    private EconomyResponse withdraw(OfflinePlayer player, double amount) {
        if (player == null) {
            return fail(0, "Jugador invalido.");
        }
        UUID id = player.getUniqueId();
        if (Double.isNaN(amount) || Double.isInfinite(amount) || amount < 0) {
            return fail(data.get(id), "Cantidad invalida.");
        }
        double value = round(amount);
        synchronized (data) {
            double balance = data.get(id);
            if (balance < value) {
                return fail(balance, "Fondos insuficientes.");
            }
            double newBalance = round(balance - value);
            data.set(id, newBalance);
            return new EconomyResponse(value, newBalance, ResponseType.SUCCESS, null);
        }
    }

    private EconomyResponse deposit(OfflinePlayer player, double amount) {
        if (player == null) {
            return fail(0, "Jugador invalido.");
        }
        UUID id = player.getUniqueId();
        if (Double.isNaN(amount) || Double.isInfinite(amount) || amount < 0) {
            return fail(data.get(id), "Cantidad invalida.");
        }
        double value = round(amount);
        synchronized (data) {
            double balance = data.get(id);
            double newBalance = round(balance + value);
            if (newBalance > maxBalance) {
                return fail(balance, "Se supera el saldo maximo.");
            }
            data.set(id, newBalance);
            return new EconomyResponse(value, newBalance, ResponseType.SUCCESS, null);
        }
    }

    /** Usado por /stars set. Devuelve false si se supera el maximo o la cantidad es invalida. */
    public boolean setBalance(OfflinePlayer player, double amount) {
        if (player == null || Double.isNaN(amount) || Double.isInfinite(amount) || amount < 0) {
            return false;
        }
        double value = round(amount);
        if (value > maxBalance) {
            return false;
        }
        data.set(player.getUniqueId(), value);
        return true;
    }

    private EconomyResponse noBanks() {
        return new EconomyResponse(0, 0, ResponseType.NOT_IMPLEMENTED, "Stars no soporta bancos.");
    }

    // ------------------------------------------------------------------
    // Informacion general
    // ------------------------------------------------------------------

    @Override
    public boolean isEnabled() {
        return true;
    }

    @Override
    public String getName() {
        return "Stars";
    }

    @Override
    public boolean hasBankSupport() {
        return false;
    }

    @Override
    public int fractionalDigits() {
        return decimals;
    }

    @Override
    public String format(double amount) {
        String pattern = decimals > 0 ? "#,##0." + "0".repeat(decimals) : "#,##0";
        DecimalFormat formatter = new DecimalFormat(pattern, DecimalFormatSymbols.getInstance(Locale.US));
        return symbol + formatter.format(amount);
    }

    @Override
    public String currencyNamePlural() {
        return plural;
    }

    @Override
    public String currencyNameSingular() {
        return singular;
    }

    // ------------------------------------------------------------------
    // Cuentas
    // ------------------------------------------------------------------

    @Override
    public boolean hasAccount(String playerName) {
        return hasAccount(byName(playerName));
    }

    @Override
    public boolean hasAccount(OfflinePlayer player) {
        return player != null
                && (data.exists(player.getUniqueId()) || player.hasPlayedBefore() || player.isOnline());
    }

    @Override
    public boolean hasAccount(String playerName, String worldName) {
        return hasAccount(playerName);
    }

    @Override
    public boolean hasAccount(OfflinePlayer player, String worldName) {
        return hasAccount(player);
    }

    @Override
    public boolean createPlayerAccount(String playerName) {
        return createPlayerAccount(byName(playerName));
    }

    @Override
    public boolean createPlayerAccount(OfflinePlayer player) {
        if (player == null || data.exists(player.getUniqueId())) {
            return false;
        }
        data.get(player.getUniqueId());
        return true;
    }

    @Override
    public boolean createPlayerAccount(String playerName, String worldName) {
        return createPlayerAccount(playerName);
    }

    @Override
    public boolean createPlayerAccount(OfflinePlayer player, String worldName) {
        return createPlayerAccount(player);
    }

    // ------------------------------------------------------------------
    // Saldo
    // ------------------------------------------------------------------

    @Override
    public double getBalance(String playerName) {
        return getBalance(byName(playerName));
    }

    @Override
    public double getBalance(OfflinePlayer player) {
        return player == null ? 0 : data.get(player.getUniqueId());
    }

    @Override
    public double getBalance(String playerName, String world) {
        return getBalance(playerName);
    }

    @Override
    public double getBalance(OfflinePlayer player, String world) {
        return getBalance(player);
    }

    @Override
    public boolean has(String playerName, double amount) {
        return has(byName(playerName), amount);
    }

    @Override
    public boolean has(OfflinePlayer player, double amount) {
        return player != null && data.get(player.getUniqueId()) >= round(amount);
    }

    @Override
    public boolean has(String playerName, String worldName, double amount) {
        return has(playerName, amount);
    }

    @Override
    public boolean has(OfflinePlayer player, String worldName, double amount) {
        return has(player, amount);
    }

    // ------------------------------------------------------------------
    // Retirar / depositar
    // ------------------------------------------------------------------

    @Override
    public EconomyResponse withdrawPlayer(String playerName, double amount) {
        return withdraw(byName(playerName), amount);
    }

    @Override
    public EconomyResponse withdrawPlayer(OfflinePlayer player, double amount) {
        return withdraw(player, amount);
    }

    @Override
    public EconomyResponse withdrawPlayer(String playerName, String worldName, double amount) {
        return withdraw(byName(playerName), amount);
    }

    @Override
    public EconomyResponse withdrawPlayer(OfflinePlayer player, String worldName, double amount) {
        return withdraw(player, amount);
    }

    @Override
    public EconomyResponse depositPlayer(String playerName, double amount) {
        return deposit(byName(playerName), amount);
    }

    @Override
    public EconomyResponse depositPlayer(OfflinePlayer player, double amount) {
        return deposit(player, amount);
    }

    @Override
    public EconomyResponse depositPlayer(String playerName, String worldName, double amount) {
        return deposit(byName(playerName), amount);
    }

    @Override
    public EconomyResponse depositPlayer(OfflinePlayer player, String worldName, double amount) {
        return deposit(player, amount);
    }

    // ------------------------------------------------------------------
    // Bancos (no soportados)
    // ------------------------------------------------------------------

    @Override
    public EconomyResponse createBank(String name, String player) {
        return noBanks();
    }

    @Override
    public EconomyResponse createBank(String name, OfflinePlayer player) {
        return noBanks();
    }

    @Override
    public EconomyResponse deleteBank(String name) {
        return noBanks();
    }

    @Override
    public EconomyResponse bankBalance(String name) {
        return noBanks();
    }

    @Override
    public EconomyResponse bankHas(String name, double amount) {
        return noBanks();
    }

    @Override
    public EconomyResponse bankWithdraw(String name, double amount) {
        return noBanks();
    }

    @Override
    public EconomyResponse bankDeposit(String name, double amount) {
        return noBanks();
    }

    @Override
    public EconomyResponse isBankOwner(String name, String playerName) {
        return noBanks();
    }

    @Override
    public EconomyResponse isBankOwner(String name, OfflinePlayer player) {
        return noBanks();
    }

    @Override
    public EconomyResponse isBankMember(String name, String playerName) {
        return noBanks();
    }

    @Override
    public EconomyResponse isBankMember(String name, OfflinePlayer player) {
        return noBanks();
    }

    @Override
    public List<String> getBanks() {
        return Collections.emptyList();
    }
}
