package com.stars;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;

public class StarsPlugin extends JavaPlugin {

    private DataManager data;
    private StarsEconomy economy;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        data = new DataManager(this);
        data.load();

        economy = new StarsEconomy(this, data);
        getServer().getServicesManager().register(Economy.class, economy, this, ServicePriority.Highest);

        StarsCommand handler = new StarsCommand(this, economy, data);
        PluginCommand command = getCommand("stars");
        if (command != null) {
            command.setExecutor(handler);
            command.setTabCompleter(handler);
        }

        long period = Math.max(1L, getConfig().getLong("autosave-minutes", 5L)) * 60L * 20L;
        getServer().getScheduler().runTaskTimerAsynchronously(this, data::save, period, period);

        getLogger().info("Stars registrada como economia de Vault.");
    }

    @Override
    public void onDisable() {
        if (economy != null) {
            getServer().getServicesManager().unregister(Economy.class, economy);
        }
        if (data != null) {
            data.save();
        }
    }
}
