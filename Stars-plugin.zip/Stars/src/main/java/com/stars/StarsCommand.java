package com.stars;

import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.util.StringUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class StarsCommand implements TabExecutor {

    private final StarsPlugin plugin;
    private final StarsEconomy eco;
    private final DataManager data;

    public StarsCommand(StarsPlugin plugin, StarsEconomy eco, DataManager data) {
        this.plugin = plugin;
        this.eco = eco;
        this.data = data;
    }

    // ------------------------------------------------------------------
    // Mensajes
    // ------------------------------------------------------------------

    private String build(String key, boolean withPrefix, String... pairs) {
        String text = plugin.getConfig().getString("messages." + key, key);
        if (withPrefix) {
            text = plugin.getConfig().getString("messages.prefix", "") + text;
        }
        for (int i = 0; i + 1 < pairs.length; i += 2) {
            text = text.replace("{" + pairs[i] + "}", pairs[i + 1]);
        }
        return text;
    }

    private void send(CommandSender to, String key, String... pairs) {
        to.sendMessage(LegacyComponentSerializer.legacyAmpersand().deserialize(build(key, true, pairs)));
    }

    private void sendLine(CommandSender to, String key, String... pairs) {
        to.sendMessage(LegacyComponentSerializer.legacyAmpersand().deserialize(build(key, false, pairs)));
    }

    // ------------------------------------------------------------------
    // Comandos
    // ------------------------------------------------------------------

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            return balance(sender, null);
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "balance", "bal" -> {
                return balance(sender, args.length > 1 ? args[1] : null);
            }
            case "pay" -> {
                return pay(sender, args);
            }
            case "top" -> {
                return top(sender);
            }
            case "give", "take", "set" -> {
                return admin(sender, args);
            }
            case "reload" -> {
                if (!sender.hasPermission("stars.admin")) {
                    send(sender, "no-permission");
                    return true;
                }
                plugin.reloadConfig();
                send(sender, "reload");
                return true;
            }
            default -> {
                send(sender, "usage");
                if (sender.hasPermission("stars.admin")) {
                    send(sender, "usage-admin");
                }
                return true;
            }
        }
    }

    private boolean balance(CommandSender sender, String targetName) {
        if (targetName == null) {
            if (!(sender instanceof Player player)) {
                send(sender, "player-only");
                return true;
            }
            if (!sender.hasPermission("stars.use")) {
                send(sender, "no-permission");
                return true;
            }
            send(sender, "balance-self", "balance", eco.format(data.get(player.getUniqueId())));
            return true;
        }

        if (!sender.hasPermission("stars.balance.others")) {
            send(sender, "no-permission");
            return true;
        }
        OfflinePlayer target = findPlayer(targetName);
        if (target == null) {
            send(sender, "player-not-found", "player", targetName);
            return true;
        }
        send(sender, "balance-other",
                "player", nameOf(target),
                "balance", eco.format(data.get(target.getUniqueId())));
        return true;
    }

    private boolean pay(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            send(sender, "player-only");
            return true;
        }
        if (!player.hasPermission("stars.pay")) {
            send(player, "no-permission");
            return true;
        }
        if (args.length < 3) {
            send(player, "usage");
            return true;
        }
        OfflinePlayer target = findPlayer(args[1]);
        if (target == null) {
            send(player, "player-not-found", "player", args[1]);
            return true;
        }
        if (target.getUniqueId().equals(player.getUniqueId())) {
            send(player, "pay-self");
            return true;
        }
        Double amount = parseAmount(args[2], false);
        if (amount == null) {
            send(player, "invalid-amount");
            return true;
        }

        EconomyResponse withdrawn = eco.withdrawPlayer(player, amount);
        if (!withdrawn.transactionSuccess()) {
            send(player, "not-enough", "balance", eco.format(data.get(player.getUniqueId())));
            return true;
        }
        EconomyResponse deposited = eco.depositPlayer(target, amount);
        if (!deposited.transactionSuccess()) {
            eco.depositPlayer(player, amount); // devolver el dinero
            send(player, "max-balance");
            return true;
        }

        send(player, "pay-sent", "amount", eco.format(amount), "player", nameOf(target));
        Player online = target.getPlayer();
        if (online != null) {
            send(online, "pay-received", "amount", eco.format(amount), "player", player.getName());
        }
        return true;
    }

    private boolean top(CommandSender sender) {
        if (!sender.hasPermission("stars.use")) {
            send(sender, "no-permission");
            return true;
        }
        List<Map.Entry<UUID, Double>> entries = new ArrayList<>(data.snapshot().entrySet());
        entries.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));

        sendLine(sender, "top-header");
        int limit = Math.min(10, entries.size());
        for (int i = 0; i < limit; i++) {
            Map.Entry<UUID, Double> entry = entries.get(i);
            String name = Bukkit.getOfflinePlayer(entry.getKey()).getName();
            if (name == null) {
                name = entry.getKey().toString().substring(0, 8);
            }
            sendLine(sender, "top-line",
                    "pos", String.valueOf(i + 1),
                    "player", name,
                    "balance", eco.format(entry.getValue()));
        }
        return true;
    }

    private boolean admin(CommandSender sender, String[] args) {
        if (!sender.hasPermission("stars.admin")) {
            send(sender, "no-permission");
            return true;
        }
        if (args.length < 3) {
            send(sender, "usage-admin");
            return true;
        }
        String action = args[0].toLowerCase(Locale.ROOT);
        OfflinePlayer target = findPlayer(args[1]);
        if (target == null) {
            send(sender, "player-not-found", "player", args[1]);
            return true;
        }
        Double amount = parseAmount(args[2], action.equals("set"));
        if (amount == null) {
            send(sender, "invalid-amount");
            return true;
        }

        boolean ok;
        switch (action) {
            case "give" -> ok = eco.depositPlayer(target, amount).transactionSuccess();
            case "take" -> ok = eco.withdrawPlayer(target, amount).transactionSuccess();
            default -> ok = eco.setBalance(target, amount);
        }
        if (!ok) {
            send(sender, "admin-failed");
            return true;
        }
        send(sender, "admin-" + action,
                "player", nameOf(target),
                "amount", eco.format(amount),
                "balance", eco.format(data.get(target.getUniqueId())));
        return true;
    }

    // ------------------------------------------------------------------
    // Ayudas
    // ------------------------------------------------------------------

    private Double parseAmount(String input, boolean allowZero) {
        try {
            double value = Double.parseDouble(input);
            if (Double.isNaN(value) || Double.isInfinite(value) || value < 0) {
                return null;
            }
            double rounded = eco.round(value);
            if (rounded <= 0 && !allowZero) {
                return null;
            }
            return rounded;
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private OfflinePlayer findPlayer(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) {
            return online;
        }
        OfflinePlayer offline = Bukkit.getOfflinePlayerIfCached(name);
        if (offline != null && (offline.hasPlayedBefore() || data.exists(offline.getUniqueId()))) {
            return offline;
        }
        return null;
    }

    private String nameOf(OfflinePlayer player) {
        String name = player.getName();
        return name != null ? name : player.getUniqueId().toString().substring(0, 8);
    }

    // ------------------------------------------------------------------
    // Autocompletado
    // ------------------------------------------------------------------

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> options = new ArrayList<>(List.of("balance", "pay", "top"));
            if (sender.hasPermission("stars.admin")) {
                options.addAll(List.of("give", "take", "set", "reload"));
            }
            return StringUtil.copyPartialMatches(args[0], options, new ArrayList<>());
        }
        if (args.length == 2) {
            switch (args[0].toLowerCase(Locale.ROOT)) {
                case "balance", "bal", "pay", "give", "take", "set" -> {
                    List<String> names = new ArrayList<>();
                    for (Player online : Bukkit.getOnlinePlayers()) {
                        names.add(online.getName());
                    }
                    return StringUtil.copyPartialMatches(args[1], names, new ArrayList<>());
                }
                default -> {
                    return Collections.emptyList();
                }
            }
        }
        return Collections.emptyList();
    }
}
