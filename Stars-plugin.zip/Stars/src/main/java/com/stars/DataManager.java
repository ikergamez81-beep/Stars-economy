package com.stars;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

public class DataManager {

    private final StarsPlugin plugin;
    private final File file;
    private final Object fileLock = new Object();
    private final Map<UUID, Double> balances = new HashMap<>();
    private boolean dirty = false;

    public DataManager(StarsPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
    }

    public synchronized void load() {
        balances.clear();
        if (!file.exists()) {
            return;
        }
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = yml.getConfigurationSection("balances");
        if (section == null) {
            return;
        }
        for (String key : section.getKeys(false)) {
            try {
                balances.put(UUID.fromString(key), section.getDouble(key));
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("UUID invalido en data.yml: " + key);
            }
        }
    }

    public synchronized boolean exists(UUID id) {
        return balances.containsKey(id);
    }

    /** Devuelve el saldo; si la cuenta no existe la crea con el saldo inicial. */
    public synchronized double get(UUID id) {
        Double value = balances.get(id);
        if (value == null) {
            value = plugin.getConfig().getDouble("starting-balance", 0.0);
            balances.put(id, value);
            dirty = true;
        }
        return value;
    }

    public synchronized void set(UUID id, double amount) {
        balances.put(id, amount);
        dirty = true;
    }

    public synchronized Map<UUID, Double> snapshot() {
        return new HashMap<>(balances);
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        synchronized (this) {
            if (!dirty) {
                return;
            }
            for (Map.Entry<UUID, Double> entry : balances.entrySet()) {
                yml.set("balances." + entry.getKey(), entry.getValue());
            }
            dirty = false;
        }
        try {
            synchronized (fileLock) {
                plugin.getDataFolder().mkdirs();
                yml.save(file);
            }
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "No se pudo guardar data.yml", ex);
            synchronized (this) {
                dirty = true;
            }
        }
    }
}
